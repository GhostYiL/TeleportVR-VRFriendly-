﻿using System;
using System.Diagnostics;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

[assembly: AssemblyVersion("3.1.0")]
[assembly: AssemblyTitle("TeleportVR-VRFriendly")]
[assembly: AssemblyCopyright("Moddel BY GhostiL (original idea)=>Janni9009")]
