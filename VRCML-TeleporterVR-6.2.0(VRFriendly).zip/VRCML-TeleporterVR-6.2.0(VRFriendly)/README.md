# VRCML-TeleporterVR_VRFriendly
Teleport mod for VRChat (using VRCModLoader) Currently VR-compatible (Thx Jen for original mod and also everyone else who helped him, i just made an small upgrade in this mod(Also my code is a mess ;D))
Now you can use MenuUI!!Its easy as 1,2,9...Enjoy!
> When compiling from source, make sure to remove and add all references
